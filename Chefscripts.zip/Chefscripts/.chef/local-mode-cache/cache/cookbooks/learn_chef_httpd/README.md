# learn_chef_httpd

Installs and configures package httpd and sets a basic home page. This cookbook is used by the Learn Chef tutorials. http://learn.getchef.com
