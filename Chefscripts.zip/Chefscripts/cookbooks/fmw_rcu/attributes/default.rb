include_attribute 'fmw_wls'

default['fmw_rcu']['db_sys_user']     = 'sys'
default['fmw_rcu']['rcu_prefix']      = 'DEV1'
