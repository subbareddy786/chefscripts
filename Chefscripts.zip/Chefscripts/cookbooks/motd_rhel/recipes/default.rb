#
# Cookbook Name:: motd_rhel
# Recipe:: default
#
# Copyright 2016, Varnika IT Service Inc.
#
# All rights reserved - Do Not Redistribute
#
template '/etc/motd' do
  source 'server-info.erb'
  mode '0644'
end
