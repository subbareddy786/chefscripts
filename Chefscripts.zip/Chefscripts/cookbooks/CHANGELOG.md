# Change Log

## chef-samples v0.1.2 (12 Jul 2016)

- Support for WebLogic/FMW 12.2.1.1

## chef-samples v0.1.1 (14 Mar 2016)

- Should also work on chef 11 besides 12
- Recipes will detect if the databags are encrypted or not

## chef-samples v0.1.0 (23 Jan 2016)

- Initial release